//
//  ContentView.swift
//  Group#3
//
//  Created by MEGH SHAH on 2023-09-21.
//
import SwiftUI

struct ContentView: View {
   private let splashDuration: Double = 2.0
    
    @State private var showMainView = false
    
    var body: some View {
        Group {
            if showMainView {
               
                Text("Smart Travel ")
                   
            } else {
                
                Image("Smart_travel-removebg-preview")
                    .resizable()
                    .scaledToFill()
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                    .edgesIgnoringSafeArea(.all)
                    .onAppear {
                        // Start a timer to transition to the main view
                        Timer.scheduledTimer(withTimeInterval: splashDuration, repeats: false) { _ in
                            withAnimation {
                                self.showMainView = true
                            }
                        }
                    }
            }
        }
    }
}
