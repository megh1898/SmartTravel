//
//  Group_3App.swift
//  Group#3
//
//  Created by MEGH SHAH on 2023-09-21.
//

import SwiftUI
import Firebase
import FirebaseAuth
import FirebaseFirestore



@main
struct YourApp: App {
    init() {
        FirebaseApp.configure()
    }

    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
