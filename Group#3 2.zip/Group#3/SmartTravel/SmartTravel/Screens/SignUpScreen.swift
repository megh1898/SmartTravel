//
//  SignUpScreen.swift
//  SmartTravel
//
//  Created by Sam 77 on 2023-09-21.
//

import SwiftUI

struct SignUpScreen: View {
    var body: some View {
        Text("Sign Up Screen")
    }
}

struct SignUpScreen_Previews: PreviewProvider {
    static var previews: some View {
        SignUpScreen()
    }
}
